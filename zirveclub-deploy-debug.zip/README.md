# ZirveClub Sistemi

Modern görev tabanlı gelişim sistemi.

## Özellikler

- Kullanıcı kayıt ve giriş sistemi
- Görev tabanlı ilerleme sistemi
- Admin paneli
- Para çekme talepleri
- Ödeme dekontları
- Real-time güncellemeler

## Kurulum

1. Bağımlılıkları yükleyin:
```bash
npm install
```

2. Environment variables ayarlayın:
```bash
cp env.example .env
```

3. Sunucuyu başlatın:
```bash
npm start
```

## Production Deployment

### Heroku
```bash
heroku create zirveclub-app
git push heroku main
```

### VPS/Shared Hosting
1. Dosyaları sunucuya yükleyin
2. `npm install` çalıştırın
3. `npm start` ile başlatın

## Admin Girişi

- Kullanıcı Adı: admin
- Şifre: admin123

## Lisans

MIT 